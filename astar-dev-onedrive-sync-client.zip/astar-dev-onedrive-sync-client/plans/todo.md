# TODO

## Done

- Align sync progress reporter delegate to include `HashedAccountId` and update call sites/tests.
- Refactor `IAuthService` and `FolderTreeService` to use functional `Result` and `Option` patterns.
- Resolve `Unit` type ambiguity in presentation and test layers.
- Update UI and test suites to align with functional architectural shifts.
