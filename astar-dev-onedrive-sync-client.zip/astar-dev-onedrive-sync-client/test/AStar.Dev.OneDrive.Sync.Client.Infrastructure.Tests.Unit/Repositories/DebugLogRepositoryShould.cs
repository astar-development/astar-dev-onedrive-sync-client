using AStar.Dev.OneDrive.Sync.Client.Core;
using AStar.Dev.OneDrive.Sync.Client.Core.Data.Entities;
using AStar.Dev.OneDrive.Sync.Client.Core.Models;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Data;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace AStar.Dev.OneDrive.Sync.Client.Infrastructure.Tests.Unit.Repositories;

public class DebugLogRepositoryShould
{
    private readonly PooledDbContextFactory<SyncDbContext> _contextFactory;

    public DebugLogRepositoryShould() => _contextFactory = new PooledDbContextFactory<SyncDbContext>(
            new DbContextOptionsBuilder<SyncDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options);

    [Fact(Skip = "Requires refactor to support new production code structure")]
    public async Task GetByAccountIdWithPagingReturnsCorrectRecords()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory);
        await SeedDebugLogsAsync(context, "acc1", 10);

        IReadOnlyList<DebugLogEntry> result = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), 5, 0, TestContext.Current.CancellationToken);

        result.Count.ShouldBe(5);
    }

    [Fact(Skip = "Requires refactor to support new production code structure")]
    public async Task GetByAccountIdWithPagingSkipsCorrectRecords()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory);
        await SeedDebugLogsAsync(context, "acc1", 10);

        IReadOnlyList<DebugLogEntry> result = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), 5, 5, TestContext.Current.CancellationToken);

        result.Count.ShouldBe(5);
    }

    [Fact(Skip = "Requires refactor to support new production code structure")]
    public async Task GetByAccountIdReturnsAllRecordsForAccount()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory);
        await SeedDebugLogsAsync(context, "acc1", 15);
        await SeedDebugLogsAsync(context, "acc2", 5);

        IReadOnlyList<DebugLogEntry> result = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), TestContext.Current.CancellationToken);

        result.Count.ShouldBe(15);
        result.All(log => log.HashedAccountId == new HashedAccountId(AccountIdHasher.Hash("acc1"))).ShouldBeTrue();
    }

    [Fact(Skip = "Requires refactor to support new production code structure")]
    public async Task GetByAccountIdReturnsRecordsOrderedByTimestampDescending()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory);

        // Add logs with different timestamps
        _ = context.DebugLogs.Add(new DebugLogEntity
        {
            HashedAccountId = new HashedAccountId(AccountIdHasher.Hash("acc1")),
            TimestampUtc = DateTime.UtcNow.AddHours(-2),
            LogLevel = "Info",
            Source = "Test",
            Message = "Oldest"
        });
        _ = context.DebugLogs.Add(new DebugLogEntity
        {
            HashedAccountId = new HashedAccountId(AccountIdHasher.Hash("acc1")),
            TimestampUtc = DateTime.UtcNow,
            LogLevel = "Info",
            Source = "Test",
            Message = "Newest"
        });
        _ = context.DebugLogs.Add(new DebugLogEntity
        {
            HashedAccountId = new HashedAccountId(AccountIdHasher.Hash("acc1")),
            TimestampUtc = DateTime.UtcNow.AddHours(-1),
            LogLevel = "Info",
            Source = "Test",
            Message = "Middle"
        });
        _ = await context.SaveChangesAsync(TestContext.Current.CancellationToken);

        IReadOnlyList<DebugLogEntry> result = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), TestContext.Current.CancellationToken);

        result[0].Message.ShouldBe("Newest");
        result[1].Message.ShouldBe("Middle");
        result[2].Message.ShouldBe("Oldest");
    }

    [Fact(Skip = "Requires refactor to support new production code structure")]
    public async Task DeleteByAccountIdRemovesOnlySpecifiedAccountLogs()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory);
        await SeedDebugLogsAsync(context, "acc1", 5);
        await SeedDebugLogsAsync(context, "acc2", 3);

        await repository.DeleteByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), TestContext.Current.CancellationToken);

        IReadOnlyList<DebugLogEntry> acc1Logs = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), TestContext.Current.CancellationToken);
        IReadOnlyList<DebugLogEntry> acc2Logs = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc2")), TestContext.Current.CancellationToken);
        acc1Logs.ShouldBeEmpty();
        acc2Logs.Count.ShouldBe(3);
    }

    [Fact(Skip = "Requires refactor to support new production code structure")]
    public async Task DeleteOlderThanRemovesOldRecords()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory);

        DateTimeOffset cutoff = DateTime.UtcNow.AddDays(-7);

        _ = context.DebugLogs.Add(new DebugLogEntity
        {
            HashedAccountId = new HashedAccountId(AccountIdHasher.Hash("acc1")),
            TimestampUtc = cutoff.AddDays(-1),
            LogLevel = "Info",
            Source = "Test",
            Message = "Old"
        });
        _ = context.DebugLogs.Add(new DebugLogEntity
        {
            HashedAccountId = new HashedAccountId(AccountIdHasher.Hash("acc1")),
            TimestampUtc = cutoff.AddDays(1),
            LogLevel = "Info",
            Source = "Test",
            Message = "Recent"
        });
        _ = await context.SaveChangesAsync(TestContext.Current.CancellationToken);

        await repository.DeleteOlderThanAsync(cutoff, TestContext.Current.CancellationToken);

        IReadOnlyList<DebugLogEntry> result = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("acc1")), TestContext.Current.CancellationToken);
        result.Count.ShouldBe(1);
        result[0].Message.ShouldBe("Recent");
    }

    [Fact]
    public async Task GetByAccountIdReturnsEmptyListWhenNoRecordsExist()
    {
        using SyncDbContext context = CreateInMemoryContext();
        var repository = new DebugLogRepository(_contextFactory );

        IReadOnlyList<DebugLogEntry> result = await repository.GetByAccountIdAsync(new HashedAccountId(AccountIdHasher.Hash("nonexistent")), TestContext.Current.CancellationToken);

        result.ShouldBeEmpty();
    }

    private static SyncDbContext CreateInMemoryContext()
    {
        DbContextOptions<SyncDbContext> options = new DbContextOptionsBuilder<SyncDbContext>()
            .UseInMemoryDatabase(Guid.CreateVersion7().ToString())
            .Options;

        return new SyncDbContext(options);
    }

    private static async Task SeedDebugLogsAsync(SyncDbContext context, string accountId, int count)
    {
        for(var i = 0; i < count; i++)
        {
            _ = context.DebugLogs.Add(new DebugLogEntity
            {
                HashedAccountId = new HashedAccountId(AccountIdHasher.Hash(accountId)),
                TimestampUtc = DateTime.UtcNow.AddMinutes(-i),
                LogLevel = "Info",
                Source = $"Test.Method{i}",
                Message = $"Log message {i}"
            });
        }

        _ = await context.SaveChangesAsync(TestContext.Current.CancellationToken);
    }
}
