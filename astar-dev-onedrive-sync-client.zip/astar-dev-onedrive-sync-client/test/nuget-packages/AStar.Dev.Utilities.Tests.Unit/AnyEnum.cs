﻿namespace AStar.Dev.Utilities.Tests.Unit;

internal enum AnyEnum
{
    NotDefined,
    Defined
}
