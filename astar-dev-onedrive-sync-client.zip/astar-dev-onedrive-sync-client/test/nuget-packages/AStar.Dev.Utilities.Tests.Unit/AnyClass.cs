﻿namespace AStar.Dev.Utilities.Tests.Unit;

internal sealed class AnyClass
{
    public int AnyInt { get; set; }

    public string AnyString { get; set; } = string.Empty;
}
