namespace AStar.Dev.Functional.Extensions.Tests.Unit;

internal class CustomTestException(string message) : Exception(message);
