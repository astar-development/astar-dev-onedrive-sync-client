using System.Reactive.Subjects;
using AStar.Dev.OneDrive.Sync.Client.Accounts;
using AStar.Dev.OneDrive.Sync.Client.Core;
using AStar.Dev.OneDrive.Sync.Client.Core.Models;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Data;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Repositories;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Services;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Services.Authentication;
using AStar.Dev.OneDrive.Sync.Client.Infrastructure.Services.OneDriveServices;
using AStar.Dev.OneDrive.Sync.Client.MainWindow;

using AStar.Dev.OneDrive.Sync.Client.Syncronisation;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Logging;

namespace AStar.Dev.OneDrive.Sync.Client.Tests.Integration.MainWindow;

/// <summary>
///     Integration tests for MainWindowViewModel coordinating AccountManagementViewModel and SyncTreeViewModel.
/// </summary>
public class MainWindowViewModelIntegrationShould : IDisposable
{
    private readonly AccountRepository _accountRepository;
    private readonly IAuthService _mockAuthService;
    private readonly IFolderTreeService _mockFolderTreeService;
    private readonly ISyncEngine _mockSyncEngine;
    private readonly IDebugLogger _mockDebugLogger;
    private readonly Subject<SyncState> _progressSubject;
    private readonly ISyncSelectionService _syncSelectionService;
    private readonly IDbContextFactory<SyncDbContext> _contextFactory;
    private readonly ILogger<AccountManagementViewModel> _mockLogger;
    private readonly ISyncRepository _syncRepository;

    public MainWindowViewModelIntegrationShould()
    {
        _contextFactory = new PooledDbContextFactory<SyncDbContext>(
            new DbContextOptionsBuilder<SyncDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options);
        _accountRepository = new AccountRepository(_contextFactory);
        _mockAuthService = Substitute.For<IAuthService>();
        _mockFolderTreeService = Substitute.For<IFolderTreeService>();
        _syncSelectionService = Substitute.For<ISyncSelectionService>();
        _mockSyncEngine = Substitute.For<ISyncEngine>();
        _mockDebugLogger = Substitute.For<IDebugLogger>();
        _mockLogger = Substitute.For<ILogger<AccountManagementViewModel>>();
        _syncRepository = Substitute.For<ISyncRepository>();

        _progressSubject = new Subject<SyncState>();
        _ = _mockSyncEngine.Progress.Returns(_progressSubject);

        _ = _mockFolderTreeService.GetRootFoldersAsync(Arg.Any<string>(), Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<IReadOnlyList<OneDriveFolderNode>>([]));
    }

    public void Dispose() => GC.SuppressFinalize(this);

    [Fact(Skip = "Runs on it's own but not when run with other tests - or is flaky and works sometimes when run with others")]
    public async Task LoadFoldersWhenAccountIsSelected()
    {
        var account = new AccountInfo(
            "acc-123",
            new HashedAccountId(AccountIdHasher.Hash("acc-123")),
            "test@example.com",
            @"C:\Sync",
            true,
            null,
            null,
            false,
            false,
            3,
            50,
            0);
        await _accountRepository.AddAsync(account, TestContext.Current.CancellationToken);

        var rootFolder = new OneDriveFolderNode { DriveItemId = "folder1", Name = "Documents", Path = "/Documents", IsFolder = true };
        _ = _mockFolderTreeService.GetRootFoldersAsync("acc-123", new HashedAccountId(AccountIdHasher.Hash("acc-123")), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<IReadOnlyList<OneDriveFolderNode>>([rootFolder]));

        var accountVm = new AccountManagementViewModel(_mockAuthService, _accountRepository, _mockLogger);
        var syncTreeVm = new SyncTreeViewModel(_mockFolderTreeService, _syncSelectionService, _mockSyncEngine, _mockDebugLogger, _syncRepository);
        IAutoSyncCoordinator mockCoordinator = Substitute.For<IAutoSyncCoordinator>();
        ISyncConflictRepository mockConflictRepo = Substitute.For<ISyncConflictRepository>();
        _ = mockConflictRepo.GetUnresolvedByAccountIdAsync(Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>()).Returns(Task.FromResult<IReadOnlyList<SyncConflict>>([]));
        using var sut = new MainWindowViewModel(accountVm, syncTreeVm, Substitute.For<IServiceProvider>(), mockCoordinator, _accountRepository, mockConflictRepo);

        await Task.Delay(100, TestContext.Current.CancellationToken);

        accountVm.SelectedAccount = account;
        await Task.Delay(100, TestContext.Current.CancellationToken);

        syncTreeVm.SelectedAccountId.ShouldBe("acc-123");
        syncTreeVm.Folders.ShouldNotBeEmpty();
        syncTreeVm.Folders.Count.ShouldBe(1);
        syncTreeVm.Folders[0].Name.ShouldBe("Documents");
    }

    [Fact(Skip = "Runs on it's own but not when run with other tests - or is flaky and works sometimes when run with others")]
    public async Task ClearFoldersWhenAccountIsDeselected()
    {
        var account = new AccountInfo(
            "acc-456",
            new HashedAccountId(AccountIdHasher.Hash("acc-456")),
            "user@example.com",
            @"C:\Sync2",
            true,
            null,
            null,
            false,
            false,
            3,
            50,
            0);
        await _accountRepository.AddAsync(account, TestContext.Current.CancellationToken);

        var rootFolder = new OneDriveFolderNode { DriveItemId = "folder1", Name = "Photos", Path = "/Photos", IsFolder = true };
        _ = _mockFolderTreeService.GetRootFoldersAsync("acc-456", new HashedAccountId(AccountIdHasher.Hash("acc-456")), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<IReadOnlyList<OneDriveFolderNode>>([rootFolder]));

        var accountVm = new AccountManagementViewModel(_mockAuthService, _accountRepository, _mockLogger);
        var syncTreeVm = new SyncTreeViewModel(_mockFolderTreeService, _syncSelectionService, _mockSyncEngine, _mockDebugLogger, _syncRepository);
        IAutoSyncCoordinator mockCoordinator = Substitute.For<IAutoSyncCoordinator>();
        ISyncConflictRepository mockConflictRepo = Substitute.For<ISyncConflictRepository>();
        _ = mockConflictRepo.GetUnresolvedByAccountIdAsync(Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>()).Returns(Task.FromResult<IReadOnlyList<SyncConflict>>([]));
        using var sut = new MainWindowViewModel(accountVm, syncTreeVm, Substitute.For<IServiceProvider>(), mockCoordinator, _accountRepository, mockConflictRepo);

        await Task.Delay(100, TestContext.Current.CancellationToken);
        accountVm.SelectedAccount = account;
        await Task.Delay(100, TestContext.Current.CancellationToken);

        accountVm.SelectedAccount = null;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        syncTreeVm.SelectedAccountId.ShouldBeNull();
        syncTreeVm.Folders.ShouldBeEmpty();
    }

    [Fact(Skip = "Runs on it's own but not when run with other tests - or is flaky and works sometimes when run with others")]
    public async Task SwitchFoldersWhenDifferentAccountIsSelected()
    {
        var account1 = new AccountInfo("acc-1",
            new HashedAccountId(AccountIdHasher.Hash("acc-1")), "user1@example.com", @"C:\Sync1", true, null, null, false, false, 3, 50, 0);
        var account2 = new AccountInfo("acc-2",
            new HashedAccountId(AccountIdHasher.Hash("acc-2")), "user2@example.com", @"C:\Sync2", true, null, null, false, false, 3, 50, 0);
        await _accountRepository.AddAsync(account1, TestContext.Current.CancellationToken);
        await _accountRepository.AddAsync(account2, TestContext.Current.CancellationToken);

        var folder1 = new OneDriveFolderNode { DriveItemId = "f1", Name = "Folder1", Path = "/Folder1", IsFolder = true };
        var folder2 = new OneDriveFolderNode { DriveItemId = "f2", Name = "Folder2", Path = "/Folder2", IsFolder = true };

        _ = _mockFolderTreeService.GetRootFoldersAsync("acc-1", Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<IReadOnlyList<OneDriveFolderNode>>([folder1]));
        _ = _mockFolderTreeService.GetRootFoldersAsync("acc-2", Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<IReadOnlyList<OneDriveFolderNode>>([folder2]));

        var accountVm = new AccountManagementViewModel(_mockAuthService, _accountRepository, _mockLogger);
        var syncTreeVm = new SyncTreeViewModel(_mockFolderTreeService, _syncSelectionService, _mockSyncEngine, _mockDebugLogger, _syncRepository);
        IAutoSyncCoordinator mockCoordinator = Substitute.For<IAutoSyncCoordinator>();
        ISyncConflictRepository mockConflictRepo = Substitute.For<ISyncConflictRepository>();
        _ = mockConflictRepo.GetUnresolvedByAccountIdAsync(Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>()).Returns(Task.FromResult<IReadOnlyList<SyncConflict>>([]));
        using var sut = new MainWindowViewModel(accountVm, syncTreeVm, Substitute.For<IServiceProvider>(), mockCoordinator, _accountRepository, mockConflictRepo);

        await Task.Delay(100, TestContext.Current.CancellationToken);
        accountVm.SelectedAccount = account1;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        var firstFolder = syncTreeVm.Folders.FirstOrDefault()?.Name;

        accountVm.SelectedAccount = account2;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        var secondFolder = syncTreeVm.Folders.FirstOrDefault()?.Name;

        firstFolder.ShouldBe("Folder1");
        secondFolder.ShouldBe("Folder2");
        syncTreeVm.SelectedAccountId.ShouldBe("acc-2");
    }

    [Fact(Skip = "Runs on it's own but not when run with other tests - or is flaky and works sometimes when run with others")]
    public async Task HandleErrorsGracefullyWhenFolderLoadingFails()
    {
        var account = new AccountInfo("acc-999",
            new HashedAccountId(AccountIdHasher.Hash("acc-999")), "error@example.com", @"C:\Sync", true, null, null, false, false, 3, 50, 0);
        await _accountRepository.AddAsync(account, TestContext.Current.CancellationToken);

        _ = _mockFolderTreeService.GetRootFoldersAsync("acc-999", Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromException<IReadOnlyList<OneDriveFolderNode>>(
                new InvalidOperationException("Network error")));

        var accountVm = new AccountManagementViewModel(_mockAuthService, _accountRepository, _mockLogger);
        var syncTreeVm = new SyncTreeViewModel(_mockFolderTreeService, _syncSelectionService, _mockSyncEngine, _mockDebugLogger, _syncRepository);
        IAutoSyncCoordinator mockCoordinator = Substitute.For<IAutoSyncCoordinator>();
        ISyncConflictRepository mockConflictRepo = Substitute.For<ISyncConflictRepository>();
        _ = mockConflictRepo.GetUnresolvedByAccountIdAsync(Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>()).Returns(Task.FromResult<IReadOnlyList<SyncConflict>>([]));
        using var sut = new MainWindowViewModel(accountVm, syncTreeVm, Substitute.For<IServiceProvider>(), mockCoordinator, _accountRepository, mockConflictRepo);

        await Task.Delay(100, TestContext.Current.CancellationToken);

        accountVm.SelectedAccount = account;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        syncTreeVm.ErrorMessage.ShouldNotBeNullOrEmpty();
        syncTreeVm.Folders.ShouldBeEmpty();
    }

    [Fact(Skip = "Runs on it's own but not when run with other tests - or is flaky and works sometimes when run with others")]
    public async Task LoadFreshFolderInstancesWhenAccountIsReselected()
    {
        var account = new AccountInfo("acc-sel",
            new HashedAccountId(AccountIdHasher.Hash("acc-sel")), "sel@example.com", @"C:\Sync", true, null, null, false, false, 3, 50, 0);
        await _accountRepository.AddAsync(account, TestContext.Current.CancellationToken);

        // Create new instances each time to simulate fresh load from API
        _ = _mockFolderTreeService.GetRootFoldersAsync("acc-sel", new HashedAccountId(AccountIdHasher.Hash("acc-sel")), Arg.Any<CancellationToken>())
            .Returns(_ => Task.FromResult<IReadOnlyList<OneDriveFolderNode>>([
                new OneDriveFolderNode { DriveItemId = "f1", Name = "TestFolder", Path = "/TestFolder", IsFolder = true }
            ]));

        var accountVm = new AccountManagementViewModel(_mockAuthService, _accountRepository, _mockLogger);
        var syncTreeVm = new SyncTreeViewModel(_mockFolderTreeService, _syncSelectionService, _mockSyncEngine, _mockDebugLogger, _syncRepository);
        IAutoSyncCoordinator mockCoordinator = Substitute.For<IAutoSyncCoordinator>();
        ISyncConflictRepository mockConflictRepo = Substitute.For<ISyncConflictRepository>();
        _ = mockConflictRepo.GetUnresolvedByAccountIdAsync(Arg.Any<HashedAccountId>(), Arg.Any<CancellationToken>()).Returns(Task.FromResult<IReadOnlyList<SyncConflict>>([]));
        using var sut = new MainWindowViewModel(accountVm, syncTreeVm, Substitute.For<IServiceProvider>(), mockCoordinator, _accountRepository, mockConflictRepo);

        await Task.Delay(100, TestContext.Current.CancellationToken);
        accountVm.SelectedAccount = account;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        OneDriveFolderNode folderToSelect = syncTreeVm.Folders[0];
        _ = syncTreeVm.ToggleSelectionCommand.Execute(folderToSelect).Subscribe();
        await Task.Delay(50, TestContext.Current.CancellationToken);

        SelectionState initialState = folderToSelect.SelectionState;

        accountVm.SelectedAccount = null;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        accountVm.SelectedAccount = account;
        await Task.Delay(100, TestContext.Current.CancellationToken);
        OneDriveFolderNode reloadedFolder = syncTreeVm.Folders[0];
        reloadedFolder.SelectionState.ShouldBe(SelectionState.Unchecked);
        initialState.ShouldBe(SelectionState.Checked);
    }
}
