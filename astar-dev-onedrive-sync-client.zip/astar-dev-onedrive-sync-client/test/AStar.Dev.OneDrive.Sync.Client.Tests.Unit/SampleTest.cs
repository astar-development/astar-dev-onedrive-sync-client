namespace AStar.Dev.OneDrive.Sync.Client.Tests.Unit;

/// <summary>
///     Sample test to verify test infrastructure is working.
/// </summary>
public class SampleTestShould
{
    [Fact]
    public void PassToVerifyTestInfrastructure()
    {
        var result = 2 + 2;

        result.ShouldBe(4);
    }
}
