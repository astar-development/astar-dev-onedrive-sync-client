using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("AStar.Dev.Logging.Extensions.Tests.Unit")]
