namespace AStar.Dev.Logging.Extensions.Messages;

/// <summary>
///     Provides strongly-typed logging methods for common HTTP status codes and errors in AStar applications.
/// </summary>
public static partial class AStarLog
{
}
