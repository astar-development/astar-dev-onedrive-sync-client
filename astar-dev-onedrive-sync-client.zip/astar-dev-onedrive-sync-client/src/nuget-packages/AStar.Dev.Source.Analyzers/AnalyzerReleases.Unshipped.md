﻿# Unshipped Analyzer Releases

See the [release tracking guidance](https://github.com/dotnet/roslyn-analyzers/blob/main/src/Microsoft.CodeAnalysis.Analyzers/ReleaseTrackingAnalyzers.Help.md).

## New Rules

| Rule ID | Category | Severity | Notes |
| --- | --- | --- | --- |
| ASTAROPT002 | AStar.Dev.Source.Analyzers | Error | AutoRegisterOptionsPartialAnalyzer |
| ASTAROPT003 | AStar.Dev.Source.Analyzers | Error | AutoRegisterOptionsPartialAnalyzer |
