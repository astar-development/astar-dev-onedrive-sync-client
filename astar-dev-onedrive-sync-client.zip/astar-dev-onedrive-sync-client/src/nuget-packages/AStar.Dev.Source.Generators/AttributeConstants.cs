﻿namespace AStar.Dev.Source.Generators;

public static class AttributeConstants
{
    public const string AttributeNamespace = "AStar.Dev.Source.Generators.Attributes";
    public const string StrongIdAttributeName = "StrongIdAttribute";
}
