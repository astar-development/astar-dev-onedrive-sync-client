using AStar.Dev.Source.Generators.Attributes;

namespace AStar.Dev.OneDrive.Sync.Client.Core.Models;

[StrongId(typeof(string))]
public readonly partial record struct HashedAccountId;
