using AStar.Dev.OneDrive.Sync.Client.Core.Models;

namespace AStar.Dev.OneDrive.Sync.Client.Infrastructure.Repositories;

/// <summary>
///     Repository for accessing debug log entries.
/// </summary>
public interface IDebugLogRepository
{
    /// <summary>
    ///     Gets debug log entries for a specific account with paging support.
    /// </summary>
    /// <param name="hashedAccountId">The hashed account ID to filter by.</param>
    /// <param name="pageSize">Number of records to retrieve.</param>
    /// <param name="skip">Number of records to skip.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>List of debug log entries ordered by timestamp descending (newest first).</returns>
    Task<IReadOnlyList<DebugLogEntry>> GetByAccountIdAsync(HashedAccountId hashedAccountId, int pageSize, int skip, CancellationToken cancellationToken = default);

    /// <summary>
    ///     Gets the count of debug log entries for a specific account.
    /// </summary>
    /// <param name="hashedAccountId">The hashed account ID to filter by.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The count of debug log entries for the account.</returns>
    Task<int> GetDebugLogCountByAccountIdAsync(HashedAccountId hashedAccountId, CancellationToken cancellationToken = default);

    /// <summary>
    ///     Gets all debug log entries for a specific account.
    /// </summary>
    /// <param name="hashedAccountId">The hashed account ID to filter by.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>List of all debug log entries for the account.</returns>
    Task<IReadOnlyList<DebugLogEntry>> GetByAccountIdAsync(HashedAccountId hashedAccountId, CancellationToken cancellationToken = default);

    /// <summary>
    ///     Deletes all debug log entries for a specific account.
    /// </summary>
    /// <param name="hashedAccountId">The hashed account ID to filter by.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task DeleteByAccountIdAsync(HashedAccountId hashedAccountId, CancellationToken cancellationToken = default);

    /// <summary>
    ///     Deletes debug log entries older than the specified date.
    /// </summary>
    /// <param name="olderThan">Delete entries older than this date.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task DeleteOlderThanAsync(DateTimeOffset olderThan, CancellationToken cancellationToken = default);

    /// <summary>
    ///    Adds a new debug log entry to the repository.
    /// </summary>
    /// <param name="debugLogEntry">The debug log entry to add.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    Task AddAsync(DebugLogEntry debugLogEntry, CancellationToken cancellationToken);
}
